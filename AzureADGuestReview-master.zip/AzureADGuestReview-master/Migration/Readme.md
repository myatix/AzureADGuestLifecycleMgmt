This PowerShell script queries your log analytics wokspace for guest user invitations and populates the guest inviter as the manager of the guest account in Azure AD.

It's intended as a migration tool to onboard the Azure AD Guest Review solution.